/*
Iterators are pointer-like entities that are used to access individual data items (which are usually called elements), in a container. Often they are used to move sequentially from element to
element, a process called iterating through the container. You can increment iterators with the
++ operator so they point to the next element, and dereference them with the * operator to
obtain the value of the element they point to. In the STL an iterator is represented by an object
of an iterator class.
Different classes of iterators must be used with different types of container. There are three
major classes of iterators: forward, bidirectional, and random access. A forward iterator can
only move forward through the container, one item at a time. Its ++ operator accomplishes this.
It can�t move backward and it can�t be set to an arbitrary location in the middle of the container. A bidirectional iterator can move backward as well as forward, so both its ++ and --
operators are defined. A random access iterator, in addition to moving backward and forward,
can jump to an arbitrary location.

There are also two specialized kinds of iterators. An input iterator can �point to� an input
device (cin or a file) to read sequential data items into a container, and an output iterator can
�point to� an output device (cout or a file) and write elements from a container to the device.
While the values of forward, bi-directional, and random access iterators can be stored (so they
can be used later), the values of input and output iterators cannot be. This makes sense: the
first three iterators point to memory locations, while input and output iterators point to I/O
devices for which stored �pointer� values have no meaning. Table 15.6 shows the characteristics of these different kinds of iterators.

Data Access
In containers that provide random access iterators (vector and queue) it�s easy to iterate
through the container using the [] operator. Containers such as lists, which don�t support random access, require a different approach. In previous examples we�ve used a �destructive readout� to display the contents of a list by popping off the items one by one, as in the LIST and
LISTPLUS examples. A more practical approach is to define an iterator for the container. The
LISTOUT program shows how that might look:
*/
// listout.cpp
// iterator and for loop for output
#include <iostream>
#include <list>
#include <algorithm>
using namespace std;
int main()
{
	int arr[] = { 2, 4, 6, 8 };
	list<int> theList;
	for (int k = 0; k < 4; k++) //fill list with array elements
		theList.push_back(arr[k]);
	list<int>::iterator iter; //iterator to list-of-ints
	for (iter = theList.begin(); iter != theList.end(); iter++)
		cout << *iter << ' '; //display the list
	cout << endl;
	return 0;
}