#include<iostream>
#include<string>
#include<conio.h>
#include<stdio.h>

using namespace std;
int main()
{
	string ch;
	//string S;
	char C;
	getline(cin,ch);
	int count1, count2, count3, count4, count5,count6;
	count1 = 0; count2 = 0; count3 = 0; count4 = 0; count5 = 0; count6 = 0;

/*	for (int i = 0; i<ch.length(); i++) {
		if (ch[i] == 'A') {
			continue;
		}
		C = ch[i];
		cout << ch[i]<<" "<<C<<endl;
	}
*/
	cout << "\nthe final string is:\n";
	for (int i = 0; i<ch.length(); i++) {
		C = ch[i];
		if (C == 'a' || C == 'A')
			count1++;
		else if (C == 'e' || C == 'E')
			count2++;
		else if (C == 'i' || C == 'I')
			count3++;
		else if (C == 'o' || C == 'O')
			count4++;
		else if (C == 'u' || C == 'U')
			count5++;
		else {
			cout << ch[i];
		}
			
	}
	cout << "\n";
	cout << "a:" << count1 << endl;
	cout << "e:" << count2 << endl;
	cout << "i:" << count3 << endl;
	cout << "o:" << count4 << endl;
	cout << "u:" << count5 << endl;

//	cout << "\nthe final string is:\n";
//	for (int i = 0; i < count6; i++) {
//		cout << S[i];
//	}
	return 0;
}