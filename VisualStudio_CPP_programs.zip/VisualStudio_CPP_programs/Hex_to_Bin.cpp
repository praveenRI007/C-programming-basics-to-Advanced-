#include<iostream>
using namespace std;
int main()
{
	string N;
	string Bin[16] = { "0000","0001","0010","0011","0100","0101","0110","0111","1000","1001","1010","1011","1100","1101","1110","1111" };
	string Hex("0123456789ABCDEF");
	string Dec("0123456789");
	string Oct[8] = { "000","001","010","011","100","101","110","111" };
	cout << "enter the Hex number:\t";
	cin >> N;
	for (int i = 0; i < N.length(); i++)
	{
		for (int j = 0; j < Hex.length(); j++)
		{
			if (N[i] == Hex[j])
				cout << Bin[j];
		}
		
	}

	for (int i = N.length() - 1; i >= 0; i--)
	{
		for(int j=i;j-=)
	}
	return 0;

}