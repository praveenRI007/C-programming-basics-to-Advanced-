#include<iostream>
//#include<Windows.h>
using namespace std;
int main()
{/*
	int X, Y;
	X = GetSystemMetrics(SM_CXSCREEN);
	Y = GetSystemMetrics(SM_CYSCREEN);
	SetCursorPos(X, Y);
	//sleep(1000);
	*/
	cout << "hello";
}