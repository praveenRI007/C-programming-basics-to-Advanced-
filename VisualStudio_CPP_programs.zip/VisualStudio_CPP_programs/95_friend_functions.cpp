/*
The concepts of encapsulation and data hiding dictate that nonmember functions should not be
able to access an object�s private or protected data. The policy is, if you�re not a member, you
can�t get in. However, there are situations where such rigid discrimination leads to considerable
inconvenience.

Imagine that you want a function to operate on objects of two different classes. Perhaps the
function will take objects of the two classes as arguments, and operate on their private data. In
this situation there�s nothing like a friend function. Here�s a simple example, FRIEND, that
shows how friend functions can act as a bridge between two classes:

*/
// friend.cpp
// friend functions
#include <iostream>
using namespace std;
////////////////////////////////////////////////////////////////
class beta; //needed for frifunc declaration
class alpha
{
private:
	int data;
public:
	alpha() : data(3) { } //no-arg constructor
	friend int frifunc(alpha, beta); //friend function
};
////////////////////////////////////////////////////////////////
class beta
{
private:
	int data;
public:
	beta() : data(7) { } //no-arg constructor
	friend int frifunc(alpha, beta); //friend function
};
////////////////////////////////////////////////////////////////
int frifunc(alpha a, beta b) //function definition
{
	return(a.data + b.data);
}
//--------------------------------------------------------------
int main()
{
	alpha aa;
	beta bb;
	cout << frifunc(aa, bb) << endl; //call the function
	return 0;
}
/*
We want the function frifunc() to have access to both of these private data members, so we
make it a friend function. It�s declared with the friend keyword in both classes:
friend int frifunc(alpha, beta);
This declaration can be placed anywhere in the class; it doesn�t matter whether it goes in the
public or the private section.

An object of each class is passed as an argument to the function frifunc(), and it accesses the
private data member of both classes through these arguments. The function doesn�t do much:
It adds the data items and returns the sum. The main() program calls this function and prints
the result.
A minor point: Remember that a class can�t be referred to until it has been declared. Class
beta is referred to in the declaration of the function frifunc() in class alpha, so beta must be
declared before alpha. Hence the declaration

class beta;

at the beginning of the program

How serious is the breach of data integrity when friend functions are used? A friend function
must be declared as such within the class whose data it will access. Thus a programmer who
does not have access to the source code for the class cannot make a function into a friend. In
this respect, the integrity of the class is still protected. Even so, friend functions are conceptually messy, and potentially lead to a spaghetti-code situation if numerous friends muddy the
clear boundaries between classes. For this reason friend functions should be used sparingly. If
you find yourself using many friends, you may need to rethink the design of the program
*/