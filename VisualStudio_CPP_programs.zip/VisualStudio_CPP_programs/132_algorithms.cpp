/*
Member Functions
Algorithms are the heavy hitters of the STL, carrying out complex operations like sorting and
searching. However, containers also need member functions to perform simpler tasks that are
specific to a particular type of container.
*/

/*
An algorithm is a function that does something to the items in a container (or containers). As
we noted, algorithms in the STL are not member functions or even friends of container classes,
as they are in earlier container libraries, but are standalone template functions. You can use
them with built-in C++ arrays, or with container classes you create yourself (provided the class
includes certain basic functions)

Suppose you create an array of type int, with data in it:
int arr[8] = {42, 31, 7, 80, 2, 26, 19, 75};
You can then use the STL sort() algorithm to sort this array by saying
sort(arr, arr+8);
where arr is the address of the beginning of the array, and arr+8 is the past-the-end address
(one item past the end of the array)

Algorithms
The STL algorithms perform operations on collections of data. These algorithms were
designed to work with STL containers, but one of the nice things about them is that you can
apply them to ordinary C++ arrays. This may save you considerable work when programming
arrays. It also offers an easy way to learn about the algorithms, unencumbered with containers.
In this section we�ll examine how some representative algorithms are used.
*/
