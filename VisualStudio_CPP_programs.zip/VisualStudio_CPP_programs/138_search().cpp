/*
The search() Algorithm
Some algorithms operate on two containers at once. For instance, while the find() algorithm
looks for a specified value in a single container, the search() algorithm looks for a sequence
of values, specified by one container, within another container. The SEARCH example shows
how this looks
*/
// search.cpp
// searches one container for a sequence in another container
#include <iostream>
#include <algorithm>
using namespace std;
int source[] = { 11, 44, 33, 11, 22, 33, 11, 22, 44 };
int pattern[] = { 11, 22, 33 };
int main()
{
	int* ptr;
	ptr = search(source, source + 9, pattern, pattern + 3);
	if (ptr == source + 9) //if past-the-end
		cout << �No match found\n�;
	else
		cout << �Match at � << (ptr - source) << endl;
	return 0;
}