/*
The put() and get() functions, which are members of ostream and istream, respectively, can
be used to output and input single characters. Here�s a program, OCHAR, that outputs a string,
one character at a time:
*/
// ochar.cpp
// file output with characters
#include <fstream> //for file functions
#include <iostream>
#include <string>
using namespace std;
int main()
{
	string str = "Time is a great teacher, but unfortunately "
		"it kills all its pupils.Berlioz";
	ofstream outfile("TEST.TXT"); //create file for output
	for (int j = 0; j < str.size(); j++) //for each character,
		outfile.put(str[j]); //write it to file
	cout << "File written\n";
	return 0;
}