/*
Sequence Containers
A sequence container stores a set of elements in what you can visualize as a line, like houses
on a street. Each element is related to the other elements by its position along the line. Each
element (except at the ends) is preceded by one specific element and followed by another. An
ordinary C++ array is an example of a sequence container.
One problem with a C++ array is that you must specify its size at compile time; that is, in the
source code. Unfortunately, you usually don�t know, when you write the program, how much
data will be stored in the array. So you must specify an array large enough to hold what you
guess is the maximum amount of data. When the program runs, you will either waste space in
memory by not filling the array, or elicit an error message (or even blow up the program) by
running out of space. The STL provides the vector container to avoid these difficulties.

Vectors
You can think of vectors as smart arrays. They manage storage allocation for you, expanding
and contracting the size of the vector as you insert or erase data. You can use vectors much like
arrays, accessing elements with the [] operator. Such random access is very fast with vectors.

It�s also fast to add (or push) a new data item onto the end (the back) of the vector. When this
happens, the vector�s size is automatically increased to hold the new item.

Member Functions push_back(), size(), and operator[]
Our first example, VECTOR, shows the most common vector operations.
*/
// vector.cpp
// demonstrates push_back(), operator[], size()
#include <iostream>
#include <vector>
using namespace std;
int main()
{
	vector<int> v; //create a vector of ints
	v.push_back(10); //put values at end of array
	v.push_back(11);
	v.push_back(12);
	v.push_back(13);
	v[0] = 20; //replace with new values
	v[3] = 23;
	for (int j = 0; j < v.size(); j++) //display vector contents
		cout << v[j] << ' '; //20 11 12 23
	cout << endl;
	return 0;
}
