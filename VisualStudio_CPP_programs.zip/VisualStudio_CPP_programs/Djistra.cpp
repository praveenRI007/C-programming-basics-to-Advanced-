#include<deque>
#include<iostream>
#include<vector>
//#include<iomanip.h>
using namespace std;
int map;
int value;
//vector<int> M;
//vector<int> L;
vector<int> Size;

class List
{
	vector<int> Node;
	int Sum ;
public:
	
	void set(int a,int b)
	{
		Node.push_back(a);
		Node.push_back(b);
	}
	void set_n(int a, int b)
	{
		int flag = 0;
		for(int i=0;i< Node.size();i+=2)
	    {
			if (Node[i] == a && Node[i + 1] == b)
				flag = 1;
	    }
		if (flag != 1)
		{
			Node.push_back(a);
			Node.push_back(b);
		}
	}
	void put()
	{
		for (int j = 0; j < Node.size(); j++) //display vector contents
		{
			cout << Node[j] << ' ';
		}
		Size.push_back(Node.size());
	}
	int find(int i,int k)
	{
		int flag = 0;
		for (int j = 0; j < Node.size(); j+=2)
		{
			if (Node[j] == i) {
				map = k;
				value = Node[j+1];
				flag = 1;
				//NodeList[i].set(map,value);
			}
		}
		return flag;
	}
	
	int nearStart(int i) {
		int W = 0;
		for (int j = 0; j < Node.size(); j+=2) {
			if (Node[j] == i)
				W = Node[j + 1];
		}
		return W;
	}

	void Djkistra()
	{

	}

	friend int main();
	
};

int getdist(int S, int i, deque<List> NodeList,int N) 
{
	int L1 = NodeList[S].nearStart(i);
	if (L1!=0) {
		return L1;
	 }
	else 
	{
		
	}
	
}

int main()
{
	int N,a,b,c,S;
	char ch;
	int count = 0;
	cout << "enter the number of nodes in network:\n";
	cin >> N;
	deque<List> NodeList(N);
	cout << "enter the node data <start> <destination> <weight>  :\n";
	while (1) {
		cin >> a >> b >> c;
		NodeList[a].set(b,c);
		count++;
		cin >> ch;
		if (ch == 'q' || ch == 'Q')
			break;
	}
	cout << "the number of edges are:\t" << count;
	cout << "\n";
	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < N; j++)
		{
			if (j != i)
			{
				if(NodeList[j].find(i, j) > 0)
					NodeList[i].set_n(map, value);//find ... parameters(i) i finds in j
			  
			}
		}
	}
	for (int i = 0; i < N; i++)
	{
		NodeList[i].put();
		cout << endl;
	}
	cout << "Enter the start Node:\n";
	cin >> S;
	

	
	for (int i = 0; i < N ; i++)
	{
		if (i != S)
			cout << "from " << S << " to " << i << ": " << getdist(S, i, NodeList,N) << endl;
		else
			continue;
	}
	
	return 0;	 
}
