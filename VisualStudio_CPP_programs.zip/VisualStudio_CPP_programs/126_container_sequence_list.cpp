/*
Here�s another problem with arrays. Say you�re storing employee records, and you�ve arranged
them in alphabetical order by the employee�s last name. If you now want to insert a new
employee whose name starts with L, you must move all the employees from M to Z to make
room. This can be very time-consuming. The STL provides the list container, which is based
on the idea of a linked list, to solve this problem. Recall from the LINKLIST example in Chapter
10, �Pointers,� that it�s easy to insert a new item in a linked list by rearranging several pointers.


Member Functions push_front(), front(), and pop_front
Our first example, LIST, shows how data can be pushed, read, and popped from both the front
and the back.
*/
//list.cpp
//demonstrates push_front(), front(), pop_front()
#include <iostream>
#include <list>
#include<algorithm>
using namespace std;
int main()
{
	list<int> ilist;
	ilist.push_back(30); //push items on back
	ilist.push_back(40);
	ilist.push_front(90); //push items on front
	ilist.push_front(30);
	ilist.push_front(50);
	ilist.push_front(16);
	ilist.push_front(100);
	int size = ilist.size(); //number of items
	ilist.sort();
	for (int j = 0; j < size; j++)
	{
		cout << ilist.front() << ' '; //read item from front
		ilist.pop_front(); //pop item off front
	}
	cout << endl;
	return 0;
}
