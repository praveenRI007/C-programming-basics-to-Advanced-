/*
Function Objects
Some algorithms can take something called a function object as an argument. A function object
looks, to the user, much like a template function. However, it�s actually an object of a template
class that has a single member function: the overloaded () operator. This sounds mysterious,
but it�s easy to use.
Suppose you want to sort an array of numbers into descending instead of ascending order. The
SORTEMP program shows how to do it:
*/
// sortemp.cpp
// sorts array of doubles in backward order,
// uses greater<>() function object
#include <iostream>
#include <algorithm> //for sort()
#include <functional> //for greater<>
using namespace std;
//array of doubles
double fdata[] = { 19.2, 87.4, 33.6, 55.0, 11.5, 42.2 };
int main()
{ //sort the doubles
	sort(fdata, fdata + 6, greater<double>());
	for (int j = 0; j < 6; j++) //display sorted doubles
		cout << fdata[j] << � �;
	cout << endl;
	return 0;
}