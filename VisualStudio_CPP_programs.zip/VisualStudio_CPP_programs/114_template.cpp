// tempfind.cpp
// template used for function that finds number in array
#include <iostream>
using namespace std;
//--------------------------------------------------------------
//function returns index number of item, or -1 if not found
template <class atype>
int find(atype* array, atype value, int size)
{
	for (int j = 0; j < size; j++)
		if (array[j] == value)
			return j;
	return -1;
}
//--------------------------------------------------------------
char chrArr[] = { 1, 3, 5, 9, 11, 13 }; //array
char ch = 5; //value to find
int intArr[] = { 1, 3, 5, 9, 11, 13 };
int in = 6;
long lonArr[] = { 1L, 3L, 5L, 9L, 11L, 13L };
long lo = 11L;
double dubArr[] = { 1.0, 3.0, 5.0, 9.0, 11.0, 13.0 };
double db = 4.0;
int main()
{
	cout << "\n 5 in chrArray : index = " << find(chrArr, ch, 6);
	cout << "\n 6 in intArray : index = " << find(intArr, in, 6);
	cout << "\n11 in lonArray : index = " << find(lonArr, lo, 6);
	cout << "\n 4 in dubArray : index = " << find(dubArr, db, 6);
	cout << endl;
	return 0;
}
/*
template <class atype, class btype>
btype find(atype* array, atype value, btype size)
{
for(btype j=0; j<size; j++) //note use of btype
if(array[j]==value)
return j;
return static_cast<btype>(-1);
}


#define abs(n) ( (n<0) ? (-n) : (n) )

This has a similar effect to the class template in TEMPABS, because it performs a simple text
substitution and can thus work with any type. However, as we�ve noted before, macros aren�t
much used in C++. There are several problems with them. One is that macros don�t perform
any type checking. There may be several arguments to the macro that should be of the same
type, but the compiler won�t check whether or not they are. Also, the type of the value returned
isn�t specified, so the compiler can�t tell if you�re assigning it to an incompatible variable. In
any case, macros are confined to functions that can be expressed in a single statement. There
are also other, more subtle, problems with macros. On the whole it�s best to avoid them.
*/