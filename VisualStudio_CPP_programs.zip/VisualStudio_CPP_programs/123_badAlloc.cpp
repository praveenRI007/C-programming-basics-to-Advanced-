// badalloc.cpp
// demonstrates bad_alloc exception
/*
Standard C++ contains several built-in exception classes. The most commonly used is probably
bad_alloc, which is thrown if an error occurs when attempting to allocate memory with new.
*/
#include <iostream>
using namespace std;
int main()
{
	const unsigned long SIZE = 10000; //memory size
	char* ptr; //pointer to memory
	try
	{
		ptr = new char[SIZE]; //allocate SIZE bytes
	}
	catch (bad_alloc) //exception handler
	{
		cout << "\nbad_alloc exception : can�t allocate memory.\n";
		return(1);
	}
	delete[] ptr; //deallocate memory
	cout << "\nMemory use is successful.\n";
	return 0;
}
/*
Destructors Called Automatically
The exception mechanism is surprisingly sophisticated. When an exception is thrown, a
destructor is called automatically for any object that was created by the code up to that point in
the try block. This is necessary because the application won�t know which statement caused
the exception, and if it wants to recover from the error, it will (at the very least) need to start
over at the top of the try block. The exception mechanism guarantees that the code in the try
block will have been �reset,� at least as far as the existence of objects is concerned.

Handling Exceptions
After you catch an exception, you will sometimes want to terminate your application. The
exception mechanism gives you a chance to indicate the source of the error to the user, and to
perform any necessary clean-up chores before terminating. It also makes clean-up easier by
executing the destructors for objects created in the try block. This allows you to release system
resources, such as memory, that such objects may be using.
In other cases you will not want to terminate your program. Perhaps your program can figure
out what caused the error and correct it, or the user can be asked to input different data. When
this is the case, the try and catch blocks are typically embedded in a loop, so control can be returned to the beginning of the try block (which the exception mechanism has attempted to
restore to its initial state).
*/