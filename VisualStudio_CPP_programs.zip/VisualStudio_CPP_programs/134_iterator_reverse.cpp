/*
Reverse Iterators
Suppose you want to iterate backward through a container, from the end to the beginning. You
might think you could say something like

list<int>::iterator iter; //normal iterator
iter = iList.end(); //start at end
while( iter != iList.begin() ) //go to beginning
cout << *iter-- << � �; //decrement iterator

but unfortunately this doesn�t work. (For one thing, the range will be wrong (from n to 1,
instead of from n�1 to 0).
To iterate backward you can use a reverse iterator. The ITEREV program shows an example
where a reverse iterator is used to display the contents of a list in reverse order.
*/
// iterev.cpp
// demonstrates reverse iterator
#include <iostream>
#include <list>
using namespace std;
int main()
{
	int arr[] = { 2, 4, 6, 8, 10 }; //array of ints
	list<int> theList;
	for (int j = 0; j < 5; j++) //transfer array
		theList.push_back(arr[j]); //to list
	list<int>::reverse_iterator revit; //reverse iterator
	revit = theList.rbegin(); //iterate backward
	while (revit != theList.rend()) //through list,
		cout << *revit++ << ' '; //displaying output
	cout << endl;
	return 0;
}