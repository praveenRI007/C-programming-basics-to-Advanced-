//BUBBLE SORT ------->O(O^2)
// ptrsort.cpp
// sorts an array using pointers
#include <iostream>
using namespace std;
int main()
{
	void bsort(int*,int*, int); //prototype
	int N; //array size
   //test array
   //int arr[N] = { 37, 84, 62, 91, 11, 65, 57, 28, 19, 49 };
	cout << "\nenter array size:\n";
	cin >> N;
	int* arr = (int*)malloc(sizeof(int) * N);
	int* index = (int*)malloc(sizeof(int) * N);
	cout << "\nenter elements of array:\n";
	for (int i = 0; i < N; i++) {
		cin >> arr[i];
		index[i] = i;
	}
	cout << "\narray index are:\t";
	for (int i = 0; i < N; i++)
		cout << index[i] <<" "<<endl;

	bsort(arr,index, N); //sort the array
	
	for (int j = 0; j < N; j++) //print out sorted array
		cout << arr[j] <<" "<<endl;
	
	cout << endl;
	cout<<"\nsorted array index is:\n"
	for (int i = 0; i < N; i++)
		cout << index[i] << " ";
	
	return 0;
}
//--------------------------------------------------------------
void bsort(int* ptr,int* ind, int n)
{
	void order(int*, int*, int*, int*); //prototype
	int j, k; //indexes to array
	for (j = 0; j < n - 1; j++) //outer loop
		for (k = 0; k < n - j - 1; k++) //inner loop starts at outer
			order(ptr + k, ptr + k + 1,ind + k,ind + k + 1); //order the pointer contents
}
//--------------------------------------------------------------
void order(int* numb1, int* numb2,int* index1, int* index2) //orders two numbers
{
	if (*numb1 > * numb2) //if 1st larger than 2nd,
	{
		int temp = *numb1; //swap them
		int temp2 = *index1;
		*numb1 = *numb2;
		*index1 = *index2;
		*numb2 = temp;
		*index2 = temp2;
	}
}