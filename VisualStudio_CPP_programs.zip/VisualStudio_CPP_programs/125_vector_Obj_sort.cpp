// sortptrs.cpp
// sorts person objects stored by pointer
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
using namespace std;
class person
{
private:
	string lastName;
	string firstName;
	long phoneNumber;
public:
	person() : //default constructor
		lastName("blank"), firstName("blank"), phoneNumber(0L)
	{ }
	//3-arg constructor
	person(string lana, string fina, long pho) :
		lastName(lana), firstName(fina), phoneNumber(pho)
	{ }
	friend bool operator<(const person&, const person&);
	friend bool operator==(const person&, const person&);
	void display() const //display person�s data
	{
		cout << endl << lastName << ", \t" << firstName
			<< "\t\tPhone: " << phoneNumber;
	}
	long get_phone() const //return phone number
	{
		return phoneNumber;
	}
}; //end class person
//--------------------------------------------------------------
//overloaded < for person class
bool operator<(const person& p1, const person& p2) {
	if (p1.lastName == p2.lastName)
		return (p1.firstName < p2.firstName) ? true : false;
	return (p1.lastName < p2.lastName) ? true : false;
}
//--------------------------------------------------------------
//overloaded == for person class
bool operator==(const person& p1, const person& p2) {
	return (p1.lastName == p2.lastName &&
		p1.firstName == p2.firstName) ? true : false;
}
//--------------------------------------------------------------
//function object to compare persons using pointers
class comparePersons {
public:
	bool operator() (const person* ptrP1,
		const person* ptrP2) const
	{
		return *ptrP1 < *ptrP2;
	}
};
//--------------------------------------------------------------
//function object to display a person, using a pointer
class displayPerson {
public:
	void operator() (const person* ptrP) const
	{
		ptrP->display();
	}
};
////////////////////////////////////////////////////////////////
int main()
{ //a vector of ptrs to persons
	vector<person*> vectPtrsPers;
	//make persons
	person* ptrP1 = new person("KuangThu", "Bruce", 4157300);
	person* ptrP2 = new person("Deauville", "William", 8435150);
	person* ptrP3 = new person("Wellington", "John", 9207404);
	person* ptrP4 = new person("Bartoski", "Peter", 6946473);
	person* ptrP5 = new person("Fredericks", "Roger", 7049982);
	person* ptrP6 = new person("McDonald", "Stacey", 7764987);
	vectPtrsPers.push_back(ptrP1); //put persons in set
	vectPtrsPers.push_back(ptrP2);
	vectPtrsPers.push_back(ptrP3);
	vectPtrsPers.push_back(ptrP4);
	vectPtrsPers.push_back(ptrP5);
	vectPtrsPers.push_back(ptrP6);
	for_each(vectPtrsPers.begin(), //display vector
		vectPtrsPers.end(), displayPerson());
	//sort pointers
	sort(vectPtrsPers.begin(), vectPtrsPers.end());
	cout << "\n\nSorted pointers";
	for_each(vectPtrsPers.begin(), //display vector
		vectPtrsPers.end(), displayPerson());
	sort(vectPtrsPers.begin(), //sort persons
		vectPtrsPers.end(), comparePersons());
	cout << "\n\nSorted persons";
	for_each(vectPtrsPers.begin(), //display vector
		vectPtrsPers.end(), displayPerson());
	while (!vectPtrsPers.empty())
	{
		delete vectPtrsPers.back(); //delete person
		vectPtrsPers.pop_back(); //pop pointer
	}
	cout << endl;
	return 0;
} //end main()

/*
The comparePersons() Function Object
If we use the two-argument version of the sort() algorithm
sort( vectPtrsPers.begin(), vectPtrsPers.end() );
then only the pointers are sorted, by their addresses in memory. This is not usually what we
want. To sort the person objects by name, we use the three-argument version of sort(), with
the comparePersons() function object as the third argument:
sort( vectPtrsPers.begin(),
bectPtrsPers.end(), comparePersons() );
The function object comparePersons() is defined like this in the SORTPTRS program:
//function object to compare persons using pointers
class comparePersons
{
public:
bool operator() (const person* ptrP1,
const person* ptrP2) const
{ return *ptrP1 < *ptrP2; }
};
The operator() takes two arguments that are pointers to persons and compares their contents,
rather than the pointers themselves.
*/

/*
The displayPerson() Function Object
We use a different approach to display the contents of a container than we have before. Instead
of iterating through the container, we use the for_each() function, with a function object as its
third argument.
for_each(vectPtrsPers.begin(),
bectPtrsPers.end(), displayPeson() );
This causes the displayPerson() function object to be called once for each person in the vector. Here�s how displayPerson() looks:
//function object to display a person, using a pointer
class displayPerson
{
public:
void operator() (const person* ptrP) const
{ ptrP->display(); }
};
With this arrangement a single function call displays all the person objects in the vector

Function Objects Used to Modify Container Behavior
In SORTPTRS we showed function objects used to modify the behavior of algorithms. Function
objects can also modify the behavior of containers. For example, if you want a set of pointers
to objects to sort itself automatically based on the objects instead of the pointers, you can use
an appropriate function object when you define the container. No sort() algorithm need be
used. We�ll examine this approach in an exercise
*/