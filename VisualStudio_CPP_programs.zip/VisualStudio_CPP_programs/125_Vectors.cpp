/*
Member Functions insert() and erase()
The insert() and erase() member functions insert or remove an element from an arbitrary
location in a container. These functions aren�t very efficient with vectors, since all the elements
above the insertion or erasure must be moved to make space for the new element or close up
the space where the erased item was. However, insertion and erasure may nevertheless be useful if speed is not a factor. The next example, VECTINS, shows how these member functions are
used:
*/
// vectins.cpp
// demonstrates insert(), erase()
#include <iostream>
#include <vector>
using namespace std;
int main()
{
	int arr[] = { 100, 110, 120, 130 }; //an array of ints
	vector<int> v(arr, arr + 4); //initialize vector to array
	cout << "\nBefore insertion : ";
	for (int j = 0; j < v.size(); j++) //display all elements
		cout << v[j] << ' ';
	v.insert(v.begin() + 2, 115); //insert 115 at element 2
	cout << "\nAfter insertion : ";
	for (int j = 0; j < v.size(); j++) //display all elements
		cout << v[j] << ' ';
	v.erase(v.begin() + 2); //erase element 2
	cout << "\nAfter erasure : ";
	for (int j = 0; j < v.size(); j++) //display all elements
		cout << v[j] << ' ';
	cout << endl;
	return 0;
}