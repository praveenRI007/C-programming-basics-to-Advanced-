/*
A map stores pairs of objects: a key object and a value object. A map is often used as a container that�s somewhat like an array, except that instead of accessing its elements with index
numbers, you access them with indices that can be of an arbitrary type. That is, the key object
serves as the index, and the value object is the value at that index.

The map and set containers allow only one key of a given value to be stored. This makes sense
in, say, a list of employees arranged by unique employee numbers. On the other hand, the
multimap and multiset containers allow multiple keys. In an English dictionary there might be
several entries for the word "set," for example.
************************************************************************************************************************
Maps and Multimaps
A map stores pairs. A pair consists of a key object and a value object. The key object contains
a key that will be searched for. The value object contains additional data. As in a set, the key
objects can be strings, numbers, or objects of more complex classes. The values are often
strings or numbers, but they can also be objects or even containers.
For example, the key could be a word, and the value could be a number representing how
many times that word appears in a document. Such a map constitutes a frequency table. Or the
key could be a word and the value could be a list of page numbers. This arrangement could
represent an index, like the one at the back of this book. Figure 15.6 shows a situation in
which the keys are words and the values are definitions, as in an ordinary dictionary.
**********************************************************************************************************************
*/
// asso_arr.cpp
// demonstrates map used as associative array
#pragma warning (disable:4786) //for map (Microsoft only)
#include <iostream>
#include <string>
#include <map>
using namespace std;
int main()
{
	string name;
	int pop;
	string states[] = { "Wyoming", "Colorado", "Nevada",
	"Montana", "Arizona", "Idaho" };
	int pops[] = { 470, 2890, 800, 787, 2718, 944 };
	map<string, int, less<string> > mapStates; //map
	map<string, int, less<string> >::iterator iter; //iterator
	for (int j = 0; j < 6; j++)
	{
		name = states[j]; //get data from arrays
		pop = pops[j];
		mapStates[name] = pop; //put it in map
	}
	cout << "Enter state : "; //get state from user
	cin >> name;
	pop = mapStates[name]; //find population
	cout << "Population: " << pop << ", 000\n";
	cout << endl; //display entire map
	for (iter = mapStates.begin(); iter != mapStates.end(); iter++)
		cout << (*iter).first << ' ' << (*iter).second << ", 000\n";
	return 0;
}

/*
The definition of a map takes three template arguments:

map<string, int, less<string> > maStates;

The first is the type of the key. In this case it�s string, representing the state name. The second
is the type of the value; in this case it�s int, which represents the population, in 1,000s. The
third argument specifies the ordering that will be used for the keys. We choose to have it
ordered alphabetically by the names of the states; that�s what less<string> does. We also
define an iterator to this map.*/