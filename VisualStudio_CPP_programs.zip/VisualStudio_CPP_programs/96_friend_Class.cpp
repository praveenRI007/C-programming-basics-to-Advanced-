// friclass.cpp
// friend classes
#include <iostream>
using namespace std;
////////////////////////////////////////////////////////////////
class alpha
{
private:
	int data1;
public:
	alpha() : data1(99) { } //constructor
	friend class beta; //beta is a friend class
};
////////////////////////////////////////////////////////////////
class beta
{ //all member functions can
public: //access private alpha data
	void func1(alpha a) { cout << "\ndata1 = " << a.data1; }
	void func2(alpha a) { cout << "\ndata1 = " << a.data1; }
};
////////////////////////////////////////////////////////////////
int main()
{
	alpha a;
	beta b;
	b.func1(a);
	b.func2(a);
	cout << endl;
	return 0;
}
/*
In class alpha the entire class beta is proclaimed a friend. Now all the member functions of
beta can access the private data of alpha (in this program, the single data item data1).
Note that in the friend declaration we specify that beta is a class using the class keyword:
friend class beta;
*/