/*

The main() program in this example creates three objects of type where.It then asks each
object to print its address, using the reveal() member function.This function prints out the
value of the this pointer.Here�s the output :
My object�s address is 0x8f4effec
My object�s address is 0x8f4effe2
My object�s address is 0x8f4effd8
Since the data in each object consists of an array of 10 bytes, the objects are spaced 10 bytes
apart in memory. (EC minus E2 is 10 decimal, as is E2 minus D8.) Some compilers may place
extra bytes in objects, making them slightly larger than 10 bytes.

// where.cpp
// the this pointer
#include <iostream>
using namespace std;
////////////////////////////////////////////////////////////////
class where
{
private:
	char charray[10]; //occupies 10 bytes
public:
	void reveal()
	{
		cout << �\nMy object�s address is � << this;
	}
};
////////////////////////////////////////////////////////////////
int main()
{
	where w1, w2, w3; //make three objects
	w1.reveal(); //see where they are
	w2.reveal();
	w3.reveal();
	cout << endl;
	return 0;
}

*/

/*
// dothis.cpp
// the this pointer referring to data
#include <iostream>
using namespace std;
////////////////////////////////////////////////////////////////
class what
{
private:
	int alpha;
public:
	void tester()
	{
		this->alpha = 11; //same as alpha = 11;
		cout << this->alpha; //same as cout << alpha;
	}
};
////////////////////////////////////////////////////////////////
int main()
{
	what w;
	w.tester();
	cout << endl;
	return 0;
}

*/

//assign2.cpp
// returns contents of the this pointer
#include <iostream>
using namespace std;
////////////////////////////////////////////////////////////////
class alpha
{
private:
	int data;
public:
	alpha() //no-arg constructor
	{ }
	alpha(int d) //one-arg constructor
	{
		data = d;
	}
	void display() //display data
	{
		cout << data;
	}
	alpha& operator = (alpha& a) //overloaded = operator
	{
		data = a.data; //not done automatically
		cout << �\nAssignment operator invoked�;
		return *this; //return copy of this alpha
	}
};
////////////////////////////////////////////////////////////////
int main()
{
	alpha a1(37);
	alpha a2, a3;
	a3 = a2 = a1; //invoke overloaded =, twice
	cout << �\na2 = �; a2.display(); //display a2
	cout << �\na3 = �; a3.display(); //display a3
	cout << endl;
	return 0;
}
/*
In this program we can use the declaration
alpha& operator = (alpha& a)
which returns by reference, instead of
alpha operator = (alpha& a)
which returns by value. The last statement in this function is
return *this;


Assignment operator invoked
Assignment operator invoked
a2=37
a3=37
Each time the equal sign is encountered in
a3 = a2 = a1;
the overloaded operator=() function is called, which prints the messages. The three objects all
end up with the same value.
You usually want to return by reference from overloaded assignment operators, using *this, to
avoid the creation of extra objects.
*/