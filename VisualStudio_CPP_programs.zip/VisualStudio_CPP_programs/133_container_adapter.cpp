/*
Container Adapters
It�s possible to create special-purpose containers from the normal containers mentioned previously using a construct called container adapters. These special-purpose containers have simpler interfaces than the more general containers. The specialized containers implemented with
container adapters in the STL are stacks, queues, and priority queues. As we noted, a stack
restricts access to pushing and popping a data item on and off the top of the stack. In a queue,
you push items at one end and pop them off the other. In a priority queue, you push data in the
front in random order, but when you pop the data off the other end, you always pop the largest
item stored: the priority queue automatically sorts the data for you.
Stacks, queues, and priority queues can be created from different sequence containers,
although the deque is often used. Table 15.4 shows the abstract data types and the sequence
containers that can be used in their implementation.

You use a template within a template to instantiate these classes. For example, here�s a stack
object that holds type int, instantiated from the deque class:
stack< deque<int> > aStak;
A detail to note about this format is that you must insert a space between the two closing angle
brackets. You can�t write
stack<deque<int>> astak; //syntax error
because the compiler will interpret the >> as an operator.

*/