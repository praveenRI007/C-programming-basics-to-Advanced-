/*
Associative Containers
An associative container is not sequential; instead it uses keys to access data. The keys, typically numbers or stings, are used automatically by the container to arrange the stored elements
in a specific order. It�s like an ordinary English dictionary, in which you access data by looking
up words arranged in alphabetical order. You start with a key value (say the word aardvark, to
use the dictionary example), and the container converts this key to the element�s location in
memory. If you know the key, you can access the associated value swiftly.

There are two kinds of associative containers in the STL: sets and maps. These both store data
in a structure called a tree, which offers fast searching, insertion, and deletion. Sets and maps
are thus very versatile general data structures suitable for a wide variety of applications.
However, it is inefficient to sort them and perform other operations that require random access.

	Sets are simpler and more commonly used than maps. A set stores a number of items which
	contain keys. The keys are the attributes used to order the items. For example, a set might store
	objects of the person class, which are ordered alphabetically using their name attributes as
	keys. In this situation, you can quickly locate a desired person object by searching for the object with a specified name. If a set stores values of a basic type such as int, the key is the
	entire item stored. Some writers refer to an entire object stored in a set as a key, but we�ll call
	it the key object to emphasize that the attribute used to order it (the key) isn�t necessarily the
	entire item.

	The map and set containers allow only one key of a given value to be stored. This makes sense
in, say, a list of employees arranged by unique employee numbers. On the other hand, the
multimap and multiset containers allow multiple keys. In an English dictionary there might be
several entries for the word "set," for example.
Creating associative containers is just like creating sequential ones:
set<int> intSet; //create a set of ints
or
multiset<employee> machinists; //create a multiset of employees

************************************************************************************************************************
Associative Containers
We�ve seen that the sequence containers (vector, list, and deque) store data items in a fixed linear sequence. Finding an item in such a container (unless its index number is known or it�s
located at an end of the container) will involve the slow process of stepping through the items
in the container one by one.
In an associative container the items are not arranged in sequence. Instead they are arranged in
a more complex way that makes it much faster to find a given item. This arrangement is typically a tree structure, although different approaches (such as hash tables) are possible. The
speed of searching is the main advantage of associative containers.
Searching is done using a key, which is usually a single value like a number or string. This
value is an attribute of the objects in the container, or it may be the entire object.
The two main categories of associative containers in the STL are sets and maps.

A set stores objects containing keys. A map stores pairs, where the first part of the pair is an
object containing a key and the second part is an object containing a value.
In both a set and a map, only one example of each key can be stored. It�s like a dictionary that
forbids more than one entry for each word. However, the STL has alternative versions of set
and map that relax this restriction. A multiset and a multimap are similar to a set and a map,
but can include multiple instances of the same key.
Associative containers share many member functions with other containers. However, some
algorithms, such as lower_bound() and equal_range(), exist only for associative containers.
Also, some member functions that do exist for other containers, such as the push and pop family (push_back() and so on) have no versions for associative containers. It wouldn�t make
sense to use push and pop with associative containers, because elements must always be
inserted in their ordered locations, not at the beginning or end of the container
************************************************************************************************************************
*/

// set.cpp
// set stores string objects
#pragma warning (disable:4786) //for set (Microsoft only)
#include <iostream>
#include <set>
#include <string>
#include<algorithm>
using namespace std;
int main()
{ //array of string objects
	string names[] = { "Juanita", "Robert","Mary", "Amanda", "Marie" };
	//initialize set to array
	set<string, less<string> > nameSet(names, names + 5);
	//iterator to set
	set<string, less<string> >::iterator iter;
	nameSet.insert("Yvette"); //insert more names
	nameSet.insert("Larry");
	nameSet.insert("Robert"); //no effect; already in set
	nameSet.insert("Barry");
	nameSet.erase("Mary"); //erase a name
	
	//display size of set
	cout << "\nSize = " << nameSet.size() << endl;
	iter = nameSet.begin(); //display members of set
	while (iter != nameSet.end())
		cout << *iter++ << '\n';
	string searchName; //get name from user
	cout << "\nEnter name to search for: ";
	cin >> searchName;
	//find matching name in set
	iter = nameSet.find(searchName);
	if (iter == nameSet.end())
		cout << "The name " << searchName << " is NOT in the set.";
	else
		cout << "The name " << *iter << " IS in the set.";
	cout << endl;

	return 0;
}