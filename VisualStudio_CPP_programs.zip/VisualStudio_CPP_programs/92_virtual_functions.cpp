/*
Virtual means existing in appearance but not in reality. When virtual functions are used, a program that appears to be calling a function of one class may in reality be calling a function of a
different class.

This is an amazing capability: Completely different functions are executed by the same function call. If the pointer in ptrarr points to a ball, the function that draws a ball is called; if it
points to a triangle, the triangle-drawing function is called. This is called polymorphism, which
means different forms. The functions have the same appearance, the draw() expression, but different actual functions are called, depending on the contents of ptrarr[j]. Polymorphism is
one of the key features of object-oriented programming, after classes and inheritance.

For the polymorphic approach to work, several conditions must be met. First, all the different
classes of shapes, such as balls and triangles, must be descended from a single base class
(called shape in MULTSHAP). Second, the draw() function must be declared to be virtual in
the base class.
*/

/*
// normal functions accessed from pointer
#include <iostream>
using namespace std;
////////////////////////////////////////////////////////////////
class Base //base class
{
public:
	void show() //normal function
	{
		cout << �Base\n�;
	}
};
////////////////////////////////////////////////////////////////
class Derv1 : public Base //derived class 1
{
public:
	void show()
	{
		cout << �Derv1\n�;
	}
};
////////////////////////////////////////////////////////////////
class Derv2 : public Base //derived class 2
{
public:
	void show()
	{
		cout << �Derv2\n�;
	}
};
////////////////////////////////////////////////////////////////
int main()
{
	Derv1 dv1; //object of derived class 1
	Derv2 dv2; //object of derived class 2
	Base* ptr; //pointer to base class
	ptr = &dv1; //put address of dv1 in pointer
	ptr->show(); //execute show()
	ptr = &dv2; //put address of dv2 in pointer
	ptr->show(); //execute show()
	return 0;
}

O/P:
Base
Base

As you can see, the function in the base class is always executed. The compiler ignores the
contents of the pointer ptr and chooses the member function that matches the type of the
pointer,
*/

// virt.cpp
// virtual functions accessed from pointer
#include <iostream>
using namespace std;
////////////////////////////////////////////////////////////////
class Base //base class
{
public:
	virtual void show() //virtual function
	{
		cout << "Base\n";
	}
};
////////////////////////////////////////////////////////////////
class Derv1 : public Base //derived class 1
{
public:
	void show()
	{
		cout << "Derv1\n";
	}
};
////////////////////////////////////////////////////////////////
class Derv2 : public Base //derived class 2
{
public:
	void show()
	{
		cout << "Derv2\n";
	}
};
////////////////////////////////////////////////////////////////
int main()
{
	Derv1 dv1; //object of derived class 1
	Derv2 dv2; //object of derived class 2
	Base* ptr; //pointer to base class
	ptr = &dv1; //put address of dv1 in pointer
	ptr->show(); //execute show()
	ptr = &dv2; //put address of dv2 in pointer
	ptr->show(); //execute show()
	return 0;
}

/*
The rule is that the compiler
selects the function based on the contents of the pointer ptr, not on the type of the pointer, as
in NOTVIRT

 At runtime, when it is known what class is pointed to by ptr, the
appropriate version of draw will be called. This is called late binding or dynamic binding.
*/