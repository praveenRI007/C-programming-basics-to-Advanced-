#include<iostream>
#include<stdio.h>
#include<conio.h>
#include<windows.h>
using namespace std;
void Print(int A[]);
void gotoxy(int x, int y);
void delay();
void delay()
{
	for (int i = 0; i < 500; i++)
	{
		//delay of 1 second
	}
}
void gotoxy(int x, int y)
{
	COORD c = { x, y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), c);
}
void SelectionSort(int A[], int n)
{
	for (int i = 0; i < n - 1; i++)
	{
		int iMin = i;
		for (int j = i + 1; j < n; j++)
		{
			if (A[j] < A[iMin])
				iMin = j;
		}
		int temp = A[i];
		A[i] = A[iMin];
		A[iMin] = temp;
		//Print(A);
		//delay();
	}
}
void Print(int A[])
{
	for (int i = 0; i < 11; i++)
	{
		gotoxy(10 + i, 10);
		for (int j = 0; j < A[i]; j++)
		{
			cout << "*";
			gotoxy(10 + i, 10 + j);
		}
	}

}
int main()
{  
	int A[7] = { 1,4,2,5,6,10,3 };
	for (int i = 1; i <= 7; i++)
	{
		gotoxy(10 + i, 10);
		for (int j = 1; j <= A[i]; j++)
		{
			cout << "*";
			gotoxy(10 + i, 10 + j);
		}
	}
	cin.get();
	/*
	int A[11] = { 1,4,2,5,6,10,3,7,9,3,4 };
	Print(A);
	SelectionSort(A, 11);
	gotoxy(20, 20);
	for (int i = 0; i < 11; i++) {
		cout << A[i] << " ";
	}
	Print(A);
	cin.get();
	*/
	}