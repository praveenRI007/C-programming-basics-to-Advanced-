/*

The third sequence container is the deque, which can be thought of as a combination of a stack
and a queue. A stack, as you may recall from previous examples, works on a last-in-first-out
principle. Both input and output take place on the top of the stack. A queue, on the other hand,
uses a first-in-first-out arrangement: data goes in at the front and comes out at the back, like a
line of customers in a bank. A deque combines these approaches so you can insert or delete
data from either end. The word deque is derived from Double-Ended QUEue. It�s a versatile
mechanism that�s not only useful in its own right, but can be used as the basis for stacks and
queues, as you�ll see later

A deque is like a vector in some ways and like a linked list in others. Like a vector, it supports
random access using the [] operator. However, like a list, a deque can be accessed at the front
as well as the back. It�s a sort of double-ended vector, supporting push_front(), pop_front(),
and front().
Memory is allocated differently for vectors and queues. A vector always occupies a contiguous
region of memory. If a vector grows too large, it may need to be moved to a new location
where it will fit. A deque, on the other hand, can be stored in several non-contiguous areas; it
is segmented. A member function, capacity(), returns the largest number of elements a vector
can store without being moved, but capacity() isn�t defined for deques because they don�t
need to be moved.
*/
// deque.cpp
// demonstrates push_back(), push_front(), front()
#include <iostream>
#include <deque>
using namespace std;
int main()
{
	deque<int> deq;
	deq.push_back(30); //push items on back
	deq.push_back(40);
	deq.push_back(50);
	deq.push_front(20); //push items on front
	deq.push_front(10);
	deq[2] = 33; //change middle item
	for (int j = 0; j < deq.size(); j++)
		cout << deq[j] << ' '; //display items
	cout << endl;
	return 0;
}
