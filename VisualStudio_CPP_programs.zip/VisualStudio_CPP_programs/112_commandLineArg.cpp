// comline.cpp
// demonstrates command-line arguments
#include <iostream>
using namespace std;
int main(int argc, char* argv[])
{
	cout << �\nargc = � << argc << endl; //number of arguments
	for (int j = 0; j < argc; j++) //display arguments
		cout << �Argument � << j << � = � << argv[j] << endl;
	return 0;
}
/*
And here�s a sample interaction with the program :
C:\C++BOOK\Chap12 > comline uno dos tres
argc = 4
Argument 0 = C:\CPP\CHAP12\COMLINE.EXE
Argument 1 = uno
Argument 2 = dos
Argument 3 = tres
To read command - line arguments, the main() function(don�t forget it�s a function!) must itself
be given two arguments.The first, argc(for argument count), represents the total number of command-line arguments.*/