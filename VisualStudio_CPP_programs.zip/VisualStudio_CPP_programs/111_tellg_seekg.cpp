/*Here�s an example that uses the two - argument version of seekg() to find a particular person
object in the GROUP.DAT file, and to display the data for that particular person.Here�s the listing
for SEEKG:
*/
// seekg.cpp
// seeks particular person in file
#include <fstream> //for file streams
#include <iostream>
using namespace std;
////////////////////////////////////////////////////////////////
class person //class of persons
{
protected:
	char name[80]; //person�s name
	int age; //person�s age
public:
	void getData() //get person�s data
	{
		cout << �\n Enter name : �; cin >> name;
		cout << � Enter age : �; cin >> age;
	}
	void showData(void) //display person�s data
	{
		cout << �\n Name : � << name;
		cout << �\n Age : � << age;
	}
};
////////////////////////////////////////////////////////////////
int main()
{
	person pers; //create person object
	ifstream infile; //create input file
	infile.open(�GROUP.DAT�, ios::in | ios::binary); //open file
	infile.seekg(0, ios::end); //go to 0 bytes from end
	int endposition = infile.tellg(); //find where we are
	int n = endposition / sizeof(person); //number of persons
	cout << �\nThere are � << n << � persons in file�;
	cout << �\nEnter person number : �;
	cin >> n;
	int position = (n - 1) * sizeof(person); //number times size
	infile.seekg(position); //bytes from start
	//read one person
	infile.read(reinterpret_cast<char*>(&pers), sizeof(pers));
	pers.showData(); //display the person
	cout << endl;
	return 0;
}
/*
Here�s the output from the program, assuming that the GROUP.DAT file is the same as that just
accessed in the DISKFUN example :
There are 3 persons in file
Enter person number : 2
Name : Rainier
Age : 21
For the user, we number the items starting at 1, although the program starts numbering at 0; so
person 2 is the second person of the three in the file.

The tellg() Function
The first thing the program does is figure out how many persons are in the file. It does this by
positioning the get pointer at the end of the file with the statement
infile.seekg(0, ios::end);
The tellg() function returns the current position of the get pointer. The program uses this
function to return the pointer position at the end of the file; this is the length of the file in
bytes. Next, the program calculates how many person objects there are in the file by dividing
by the size of a person; it then displays the result.
In the output shown, the user specifies the second object in the file, and the program calculates
how many bytes into the file this is, using seekg(). It then uses read() to read one person�s
worth of data starting from that point. Finally, it displays the data with showData().
*/