#include<iostream>
using namespace std;
int index = 0;
int max_element(int A[], int start, int end);
int main() {
	int A[] = { 42,23,6,4,3,34 };
	int size = sizeof(A) / sizeof(int);
	int terms = 2;
	int max = 0;
	int start = 0;
	int end = size;
	int temp = 0;
	int max_l = 0;
	int max_r = 0;
	max = max_element(A, start, end);
	while(terms!=0){
		if (index == start) {
			start = start + 1;
			max = max + max_element(A, start, end);
		}
		else if (index == end - 1) {
			end = end - 2;
			max = max + max_element(A, start, end);
		}
		else {
			int start_l, start_r, end_l, end_r;
			
			end_l = index - 1;
			max_l = max_element(A, start, end_l)
			
			start_r = index + 1;
			max_r = max_element(A, start_r, end);
			
			if (max_r >= max_l && max_r > temp) {
				max = max + max_r;
				temp = max_l;
			}
			else if(max_l >= max_r && max_l > temp) {
				max = max + max_l;
				if()
				temp = max_r;
			}
		}
		terms--;
	}
	cout << "the sum of triplet is:\n";
	cout << max;
	
	return 0;
}
int max_element(int A[], int start, int end) {
	//int s = start;
	int max = A[start];
	if ((end - start) == 1) {
		index = start;
		return max;
	}

	for (int i = start + 1; i < end; i++) {
		if (A[i] > max) {
			max = A[i];
			index = i;
		}
	}
	return max;
}