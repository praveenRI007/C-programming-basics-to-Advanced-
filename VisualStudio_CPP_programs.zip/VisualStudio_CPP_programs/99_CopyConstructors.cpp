/*
As we discussed, you can define and at the same time initialize an object to the value of
another object with two kinds of statements:

alpha a3(a2); // copy initialization
alpha a3 = a2; // copy initialization, alternate syntax

Both styles of definition invoke a copy constructor: a constructor that creates a new object and
copies its argument into it. The default copy constructor, which is provided automatically by
the compiler for every object, performs a member-by-member copy. This is similar to what the
assignment operator does; the difference is that the copy constructor also creates a new object.

*/
// xofxref.cpp
// copy constructor: X(X&)
#include <iostream>
using namespace std;
////////////////////////////////////////////////////////////////
class alpha
{
private:
	int data;
public:
	alpha() //no-arg constructor
	{ }
	alpha(int d) //one-arg constructor
	{
		data = d;
	}
	alpha(alpha& a) //copy constructor
	{
		data = a.data;
		cout << "\nCopy constructor invoked";
	}
	void display() //display
	{
		cout << data;
	}
	void operator = (alpha& a) //overloaded = operator
	{
		data = a.data;
		cout << "\nAssignment operator invoked";
	}
};
////////////////////////////////////////////////////////////////
int main()
{
	alpha a1(37);
	alpha a2;
	a2 = a1; //invoke overloaded =
	cout << "\na2 = "; a2.display(); //display a2
	alpha a3(a1); //invoke copy constructor
	// alpha a3 = a1; //equivalent definition of a3
	cout << "\na3 = "; a3.display(); //display a3
	cout << endl;
	return 0;
}