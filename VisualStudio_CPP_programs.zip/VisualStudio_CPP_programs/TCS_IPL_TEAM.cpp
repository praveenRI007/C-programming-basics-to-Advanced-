#include<iostream>
#include<algorithm>
#include<list>
#include<iomanip>
using namespace std;
int NoOfMatches(int N)
{
	int count = 0;
	for (int i = N - 1; i >= 1; i--)
		count = count + i;
	return count;
}
int main() 
{
	int N;
	string ch;
	list<string> names;
	list<string> names1;
	list<string>::iterator strptr = names.begin();
	list<string>::iterator strptr1;
	cout << "enter the no of IPL teams you want to enter\n";
	cin >> N;
	cout << "\ntotal number of matches:\n" << NoOfMatches(N);
	cout << "\nenter the number of teams you want to enter:\n";

	for (int i = 0; i < N; i++)
	{
		cin >> ch;
		names.push_back(ch);
	}
	cout << "\nthe teams entered are:\n";
	names1.assign(names.begin(), names.end());
	for (strptr = names.begin(); strptr!=names.end(); strptr++)
	{
		cout << *strptr << endl;
		
	}
	cout << "\n";
	/*
	for (strptr = names.begin(); strptr != names.end(); strptr++)
	{
		names.pop_front();

		for (strptr1 = names.begin(); strptr1 != names.end(); strptr1++)
		{
			cout << *strptr << " VS "<<*strptr1 <<endl;
		}
	}
	*/
	cout << "the scheduled matches are:\n";
	strptr = names.begin();
	while (strptr != names.end())
	{
		strptr = names.begin();
		string temp = *strptr;
		names.pop_front();

		for (strptr1 = names.begin(); strptr1 != names.end(); strptr1++)
		{
			cout << temp<<setw(5)<< " VS "  << *strptr1 << endl;
		}
		strptr = names.begin();
		
	}
	
	
	return 0;

}
