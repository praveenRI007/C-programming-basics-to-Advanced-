#include<iostream>
#include<string>
#include<stdio.h>
#include<process.h>

using namespace std;
int main()
{ 
	string S[12];
	int count = 0;
	
	for (int i = 0; i < 12; i++) 
	{
		cin >> S[i];
		if (S[i][0] == 'q' || S[i][0] == 'Q') {
			break;
		}
		count++;
	}
	
	
	if (count <= 3) { exit; }
	cout <<"\n"<< count;
	cout << "the listed teams are:\n";
	for (int i = 0; i < count; i++)
		cout << S[i] << endl;

	for (int i = 0; i < count - 1; i++)
	{
		for (int j = i+1; j < count; j++) 
		{
			cout << S[i] << " VS " << S[j] << endl;
		}
	}
	

	return 0;
}