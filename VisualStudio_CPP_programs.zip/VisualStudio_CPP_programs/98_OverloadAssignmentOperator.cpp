// assign.cpp
// overloads assignment operator (=)
#include <iostream>
using namespace std;
////////////////////////////////////////////////////////////////
class alpha
{
private:
	int data;
public:
	alpha() //no-arg constructor
	{ }
	alpha(int d) //one-arg constructor
	{
		data = d;
	}
	void display() //display data
	{
		cout << data;
	}
	alpha operator = (alpha& a) //overloaded = operator
	{
		data = a.data; //not done automatically
		cout << �\nAssignment operator invoked�;
		return alpha(data); //return copy of this alpha
	}
};
////////////////////////////////////////////////////////////////
int main()
{
	alpha a1(37);
	alpha a2;	a2 = a1; //invoke overloaded =
	cout << �\na2 = �; a2.display(); //display a2
	alpha a3 = a2; //does NOT invoke =
	cout << �\na3 = �; a3.display(); //display a3
	cout << endl;
	return 0;
}
/*
The alpha class is very simple; it contains only one data member. Constructors initialize the
data, and a member function can print out its value. The new aspect of ASSIGN is the function
operator=(), which overloads the = operator.
In main(), we define a1 and give it the value 37, and define a2 but give it no value. Then we
use the assignment operator to set a2 to the value of a1:
a2 = a1; // assignment statement
This causes our overloaded operator=() function to be invoked. Here�s the output from
ASSIGN:
Assignment operator invoked
a2=37
a3=37

alpha a3 = a2; // copy initialization, not an assignment
is not an assignment but an initialization, with the same effect as
alpha a3(a2); // alternative form of copy initialization

When you overload the = operator you assume responsibility for doing whatever the default
assignment operator did. Often this involves copying data members from one object to another.
The alpha class in ASSIGN has only one data item, data, so the operator=() function copies its
value with the statement
data = a.data;

The operator=() function in ASSIGN returns a value by creating a temporary alpha object and
initializing it using the one-argument constructor in the statement
return alpha(data);

Not Inherited
The assignment operator is unique among operators in that it is not inherited. If you overload
the assignment operator in a base class, you can�t use this same function in any derived classes.

 Values passed by reference don�t generate copies, and thus help to conserve memory

*/