/*
The try Block
All the statements in main() that might cause this exception�that is, statements that manipulate Stack objects�are enclosed in braces and preceded by the try keyword:
try
{
//code that operates on objects that might cause an exception
}

The Exception Handler (Catch Block)
The code that handles the exception is enclosed in braces, preceded by the catch keyword,
with the exception class name in parentheses. The exception class name must include the class
in which it is located. Here it�s Stack::Range.
catch(Stack::Range)
{
//code that handles the exception
}
This construction is called the exception handler. It must immediately follow the try block. In
XSTAK the exception handler simply prints an error message to let the user know why the program failed.

Sequence of Events
Let�s summarize the sequence of events when an exception occurs:
1. Code is executing normally outside a try block.
2. Control enters the try block.
3. A statement in the try block causes an error in a member function.
4. The member function throws an exception.
5. Control transfers to the exception handler (catch block) following the try block.
*/
// xstak.cpp
// demonstrates exceptions
#include <iostream>
using namespace std;
const int MAX = 3; //stack holds 3 integers
////////////////////////////////////////////////////////////////
class Stack
{
private:
	int st[MAX]; //array of integers
	int top; //index of top of stack
public:
	class Range //exception class for Stack
	{ //note: empty class body
	};
	Stack() //constructor
	{
		top = -1;
	}
	void push(int var)
	{
		if (top >= MAX - 1) //if stack full,
			throw Range(); //throw exception
		st[++top] = var; //put number on stack
	}
	int pop()
	{
		if (top < 0) //if stack empty,
			throw Range(); //throw exception
		return st[top--]; //take number off stack
	}
};
////////////////////////////////////////////////////////////////
int main()
{
	Stack s1;
	try
	{
		s1.push(11);
		s1.push(22);
		s1.push(33);
		// s1.push(44); //oops: stack full
		cout << "1: " << s1.pop() << endl;
		cout << "2: " << s1.pop() << endl;
		cout << "3: " << s1.pop() << endl;
		cout << "4: " << s1.pop() << endl; //oops: stack empty
	}

	catch (Stack::Range) //exception handler
	{
		cout << "Exception: Stack Full or Empty" << endl;
	}
	cout << "Arrive here after catch (or normal exit)" << endl;
	return 0;
}
/*
The exception mechanism uses three new C++ keywords: throw, catch, and try.
Also, we need to create a new kind of entity called an exception class.XSYNTAX is not a working program, but a skeleton program to show the syntax.
*/
// xsyntax.cpp
// not a working program
////////////////////////////////////////////////////////////////
/*
class AClass //a class
{
public:
	class AnError //exception class
	{
	};
	void Func() //a member function
	{
		if ( /* error condition */  /*
			throw AnError(); //throw exception
	}
};*/
////////////////////////////////////////////////////////////////
/*
int main() //application
{
	try //try block
	{
		AClass obj1; //interact with AClass objects
		obj1.Func(); //may cause error
	}
	catch (AClass::AnError) //exception handler
	{ //(catch block)
	//tell user about error, etc.
	}
	return 0;
}
*/
